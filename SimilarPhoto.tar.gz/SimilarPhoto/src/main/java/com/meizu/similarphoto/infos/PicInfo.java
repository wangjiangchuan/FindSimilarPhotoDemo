package com.meizu.similarphoto.infos;

/**
 * Created by root on 16-3-7.
 */
public class PicInfo extends BasicInfo{
    //下面是记录照片信息
    private String mPath;               //路径
    private String mNoExtensionName;     //后缀名
    private String mFileSize;            //文件大小
    private String mCreatTime;           //创建时间
    private String modifyTime;          //最近一次编辑时间
    private String mMimeType;            //
    private String mBucketName;          //所在上级目录
    private String mBucketId;            //所在上级目录的ID
    private String mTakenTime;
    private String mID;                 //资源表中的ID信息
    private long mFingerPrint;          //描述照片信息的指纹

    //构造函数
    public PicInfo(String path, String noExtensionName, String creatTime, String filesize, String modifyTime, String mimetype, String bucketName, String bucketId, String takenTime, String id) {
        this.mPath = path;
        this.mNoExtensionName = noExtensionName;
        this.mCreatTime = creatTime;
        this.mFileSize = filesize;
        this.modifyTime = modifyTime;
        this.mMimeType = mimetype;
        this.mBucketName = bucketName;
        this.mBucketId = bucketId;
        this.mTakenTime = takenTime;
        this.mID = id;
    }

    public String getPath() {
        return mPath;
    }

    public void setPath(String path) {
        this.mPath = path;
    }

    public String getNoExtensionName() {
        return mNoExtensionName;
    }

    public void setNoExtensionName(String noExtensionName) {    this.mNoExtensionName = noExtensionName; }

    public String getmFileSize() {   return mFileSize;    }

    public void setmFileSize(String mFileSize) {  this.mFileSize = mFileSize;   }

    public String getCreatTime() {
        return mCreatTime;
    }

    public void setCreatTime(String creatTime) {
        this.mCreatTime = creatTime;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getMimetype() {
        return mMimeType;
    }

    public void setMimetype(String mimetype) {
        this.mMimeType = mimetype;
    }

    public String getBucketName() {
        return mBucketName;
    }

    public void setBucketName(String bucketName) {
        this.mBucketName = bucketName;
    }

    public String getBucketId() {
        return mBucketId;
    }

    public void setBucketId(String bucketId) {
        this.mBucketId = bucketId;
    }

    public String getTakenTime() {
        return mTakenTime;
    }

    public void setTakenTime(String takenTime) {    this.mTakenTime = takenTime; }

    public String getmID() {  return mID; }

    public void setmFingerPrint(long mFingerPrint) {
        this.mFingerPrint = mFingerPrint;
    }

    public long getmFingerPrint(){
        return this.mFingerPrint;
    }
}
