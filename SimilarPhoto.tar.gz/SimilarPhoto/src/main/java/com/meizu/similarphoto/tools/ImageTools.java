package com.meizu.similarphoto.tools;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.provider.MediaStore;

import com.meizu.similarphoto.infos.PicInfo;
import com.meizu.similarphoto.infos.PicItemInfo;
import com.meizu.similarphoto.infos.PicSimilarInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


/**
 * Created by wangjiangchuan on 16-3-7.
 */
public class ImageTools {


    //查找相似图片的接口
    public static List<PicSimilarInfo> FindSimilarPhoto(Context context, int value, int time_gap) {

        List<PicSimilarInfo> similarInfoList = new ArrayList<>();
        //先将所有的图片信息查找出来，放在一个List<PicInfo> allPic 数组中
        List<PicInfo> allPic = PictureUtils.getDCIMImageList(context);
        //将allPic中所有的图片的fingerprint计算出来
        ImageTools.calculateFingerPrint(allPic, context);
        //然后将所有的PicInfo进行分组
        List<PicItemInfo> picItemInfoList = ImageTools.sortedByTimeGap(allPic, time_gap);
        if (picItemInfoList == null) {
            return null;
        } else {
            //不为空查找相似图片
            similarInfoList = ImageTools.similarySort(picItemInfoList, value);
        }
        return similarInfoList;
    }


    //按照时间间隔进行排序
    public static List<PicItemInfo> sortedByTimeGap(List<PicInfo> picInfoList, int TIME_GAP) {
        HashMap<Integer, PicItemInfo> timegroup = new HashMap<Integer, PicItemInfo>();
        List<PicItemInfo> picItemInfoList = new ArrayList<PicItemInfo>();
        //下面是讲图片进行分组
        long oldTakenTime = 0;
        int groupCount = 0;
        for (int i = 0; i < picInfoList.size(); i++) {
            PicInfo picInfo = picInfoList.get(i);
            long takenTime = Long.valueOf(picInfo.getTakenTime());
            if (Math.abs(oldTakenTime - takenTime) >= TIME_GAP) {
                List<PicInfo> childList = new ArrayList<PicInfo>();
                picInfo.setGroupId(groupCount + 1);
                childList.add(picInfo);
                PicItemInfo picItemInfo = new PicItemInfo(picInfo.getTakenTime(), childList);
                timegroup.put(++groupCount, picItemInfo);

            } else {
                picInfo.setGroupId(groupCount);
                timegroup.get(groupCount).getPicInfoList().add(picInfo);

            }
            oldTakenTime = takenTime;
        }
        picItemInfoList = subGroupOfImage(timegroup);
        return picItemInfoList;
    }


    //将得到的hashmap分组，HashMap<Integer, PicItemInfo> 到 List<PicInfoIten>
    public static List<PicItemInfo> subGroupOfImage(HashMap<Integer, PicItemInfo> mGruopMap) {
        if (mGruopMap.size() == 0) {
            return null;
        }
        List<PicItemInfo> list = new ArrayList<PicItemInfo>();

        Iterator<Map.Entry<Integer, PicItemInfo>> it = mGruopMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, PicItemInfo> entry = it.next();
            PicItemInfo picItemInfo = entry.getValue();
            list.add(picItemInfo);
        }
        return list;
    }

    //查找相似的照片
    public static List<PicSimilarInfo> similarySort(List<PicItemInfo> info_list, int value) {
        List<PicSimilarInfo> similaries = new ArrayList<>();
        if (value < 0 || value > 64) {
            value = 15;
        }
        for (int i = 0; i < info_list.size(); i++) {

            List<PicInfo> list = new ArrayList<>(info_list.get(i).getPicInfoList());
            while (list.size() > 0) {
                //得到第一张图片
                int index = list.size() - 1;
                PicInfo picInfo = list.get(index);
                list.remove(index);
                List<PicInfo> list_temp = new ArrayList<PicInfo>();
                long orign_finger = picInfo.getmFingerPrint();
                //下面的循环中将能够分到一组的DiffNum加起来，求出分到一组的DiffNum的平均值
                for (int j = list.size() - 1; j >= 0; j--) {
                    long com_finger = list.get(j).getmFingerPrint();
                    int different_num = ImageTools.compareFingerPrint(orign_finger, com_finger);
                    if (different_num <= value) {
                        list_temp.add(list.get(j));
                        list.remove(j);
                    }
                }
                if (list_temp.size() > 0) {
                    list_temp.add(picInfo);
                    PicSimilarInfo picSimilarInfo = new PicSimilarInfo(picInfo.getTakenTime(), list_temp);
                    long basefinger = orign_finger;
                    picSimilarInfo.setBaseFinger(basefinger);
                    similaries.add(picSimilarInfo);
                }
            }
        }
        return similaries;
    }
    /**
     * 得到平均值
     *
     * @param pixels 灰度值矩阵
     * @return
     */
    private static double getAverage(double[][] pixels) {
        int width = pixels[0].length;
        int height = pixels.length;
        int count = 0;
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                count += pixels[i][j];
            }
        }
        return count / (width * height);
    }

    /**
     * 得到灰度值
     *
     * @param image
     * @return
     */
    private static double[][] getGrayValue(Bitmap image) {
        int width = 8;
        int height = 8;
        double[][] pixels = new double[height][width];
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                pixels[i][j] = computeGrayValue(image.getPixel(i, j));
            }
        }
        return pixels;
    }

    /**
     * 计算灰度值
     *
     * @param pixel
     * @return
     */
    private static double computeGrayValue(int pixel) {
        int red = (pixel >> 16) & 0xFF;
        int green = (pixel >> 8) & 0xFF;
        int blue = (pixel) & 255;
        return 0.3 * red + 0.59 * green + 0.11 * blue;
    }

    public static long getFingerPrint(Bitmap image) {

        double[][] pixels = getGrayValue(image);
        double avg = getAverage(pixels);
        long fingerprint = getFingerPrint(pixels, avg);
        return fingerprint;
    }

    /**
     * 缩小图片
     *
     * @param image
     * @param width
     * @param height
     * @return
     */
    private static Bitmap reduceSize(Bitmap image, int width,
                                    int height) {
        Bitmap new_image = Bitmap.createScaledBitmap(image, width, height, true);
        return new_image;
    }
    //计算所有的图片的fingerprint
    public static void calculateFingerPrint(List<PicInfo> list, Context context) {

        float scale_width = 0f, scale_height = 0f;
        for (int i = 0; i < list.size(); i++) {
            Bitmap bitmap = MediaStore.Images.Thumbnails.getThumbnail(context.getContentResolver(),
                    Long.parseLong(list.get(i).getmID()), MediaStore.Images.Thumbnails.MICRO_KIND, null);
            //设置缩放比例
            scale_width = 8.0f / bitmap.getWidth();
            scale_height = 8.0f / bitmap.getHeight();
            Matrix matrix = new Matrix();
            matrix.postScale(scale_width, scale_height);

            Bitmap reduce_bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);
            long fingerprint = ImageTools.getFingerPrint(reduce_bitmap);

            list.get(i).setmFingerPrint(fingerprint);
        }
    }

    /**
     * 获得信息指纹
     *
     * @param pixels 灰度值矩阵
     * @param avg    平均值
     * @return 返回01串的十进制表示
     */
    private static long getFingerPrint(double[][] pixels, double avg) {

        int width = pixels[0].length;
        int height = pixels.length;
        byte[] bytes = new byte[height * width];
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                if (pixels[i][j] >= avg) {
                    bytes[i * height + j] = 1;
                } else {
                    bytes[i * height + j] = 0;
                }
            }
        }
        //两个long 来存储 64位数据，fingerprint1存储低32位，fingerprint存储高32位
        long fingerprint1 = 0;
        long fingerprint2 = 0;
        for (int i = 0; i < 64; i++) {
            if (i < 32) {
                fingerprint1 += (bytes[63 - i] << i);
            } else {
                fingerprint2 += (bytes[63 - i] << (i - 31));
            }
        }
        //合并到最终的返回值fingerprint中
        long fingerprint = (fingerprint2 << 32) + fingerprint1;
        return fingerprint;
    }


    //比较指纹的函数
    public static int compareFingerPrint(long orgin1_fingerprint, long orign2_fingerprint) {
        long temp1 = 0x01;
        int count1 = 0;
        long result = orgin1_fingerprint ^ orign2_fingerprint;
        for (int i = 0; i < 64; i++) {
            if ((result & (temp1 << i)) == 0) {
                count1++;
            }
        }
        return (64 - count1);
    }

}
